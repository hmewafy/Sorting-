
from Tournament import Tournament


def main():
    while True:
        user_input = input("Enter the number of teams (multiple of 4): ")
        try:
            num_teams = int(user_input)
            # The constructor checks further constraints.
            tour = Tournament(num_teams)
            break
        except ValueError as e:
            print(f"Invalid input: {e}")
    
    # Create the tournament
    
    tour.run_tournament()



if __name__ == "__main__":
    main()


